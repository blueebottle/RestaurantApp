import React, { useState } from "react";

export const loginRequest = (e, p, navigation) => {
  const [isEmail, setEmail] = useState("abc@xyx.io");
  const [isPassword, setPassword] = useState("test123");

  return new Promise((resolve, reject) => {
    if (e === isEmail && p === isPassword) {
      resolve(navigation.navigate("AccountScreen"));
    }
    reject("invalid");
    console.log(e && p);
  });
};
