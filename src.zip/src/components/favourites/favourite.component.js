import React, { useContext } from "react";
import { StyleSheet, TouchableOpacity } from "react-native";
import { AntDesign } from "react-native-vector-icons";
import { FavouritesContext } from "../../services/favourites/favourites.context";

export const Favourite = ({ restaurant }) => {
  const { favourites, addToFavourites, removeFromFavourites } =
    useContext(FavouritesContext);
  const isFavourite = favourites.find((r) => r.placeId === restaurant.placeId);
  console.log("favourites", favourites);
  return (
    <TouchableOpacity
      onPress={() =>
        !isFavourite
          ? addToFavourites(restaurant)
          : removeFromFavourites(restaurant)
      }
      style={styles.container}
    >
      <AntDesign
        name={isFavourite ? "heart" : "hearto"}
        color={isFavourite ? "red" : "white"}
        size={25}
      />
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  container: {
    zIndex: 9,
    padding: 10,
    position: "absolute",
    right: 13,
    marginTop: 10,
  },
});
