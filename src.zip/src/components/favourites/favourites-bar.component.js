import React from "react";
import { StyleSheet, View, TouchableOpacity, Text } from "react-native";
import { ScrollView } from "react-native-gesture-handler";
import { CompactRestaurantInfo } from "../restaurant/compact-restaurant-info.component";

export const FavouritesBar = ({ favourites, onNavigate }) => {
  return (
    <View style={styles.container}>
      <Text style={{ marginBottom: 10 }}>Favourites</Text>
      <ScrollView horizontal showsHorizontalScrollIndicator={false}>
        {favourites.map((restaurant) => {
          const key = restaurant.name;
          console.log(restaurant);
          return (
            <TouchableOpacity
              style={styles.button}
              onPress={() =>
                onNavigate("RestaurantDetail", {
                  restaurant,
                })
              }
            >
              <CompactRestaurantInfo restaurant={restaurant} />
            </TouchableOpacity>
          );
        })}
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    padding: 10,
    marginLeft: 10,
  },
  button: {
    marginRight: 10,
  },
});
