import React, { useContext } from "react";
import { TouchableOpacity, Text, Image, StyleSheet } from "react-native";

export const CompactRestaurantInfo = ({ restaurant }) => {
  return (
    <TouchableOpacity style={styles.container}>
      <Image style={styles.image} source={{ uri: restaurant.photos[0] }} />
      <Text style={styles.text}>{restaurant.name}</Text>
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  container: {
    maxWidth: 120,
    alignItems: "center",
  },
  image: {
    height: 100,
    width: 120,
    borderRadius: 20,
  },
  text: {
    fontFamily: "cochin",
  },
});
