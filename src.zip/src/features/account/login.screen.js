import React, { useContext, useState } from "react";
import { View, ImageBackground, StyleSheet, Text } from "react-native";
import { TouchableOpacity } from "react-native-gesture-handler";
import { Button, TextInput } from "react-native-paper";
import { AuthenticationContext } from "../../services/authentication/authentication.context";
import { AppNavigator } from "../../infrastructure/navigation/app.navigator";
import { Navigation } from "../../infrastructure/navigation";
import LottieView from "lottie-react-native";

export const LoginScreen = ({ navigation }) => {
  const [email, setEmail] = useState("");
  const [pass, setPass] = useState("");
  const { onLogin } = useContext(AuthenticationContext);
  return (
    <View style={styles.container}>
      <ImageBackground
        style={styles.image}
        source={require("/Users/developer/Desktop/Vidipta/Projects/MealsToGo/home_bg.jpg")}
      >
        <View
          style={{
            marginTop: 50,
            width: "100%",
            height: "40%",
            opacity: 1,
            position: "absolute",
          }}
        >
          <LottieView
            key="animation"
            autoPlay
            loop
            resizeMode="cover"
            source={require("/Users/developer/Desktop/Vidipta/Projects/MealsToGo/assets/watermelon.json")}
          />
        </View>
        <Button
          style={styles.backbutton}
          mode="contained"
          color="black"
          onPress={() => {
            navigation.navigate("AccountScreen");
          }}
        >
          back
        </Button>
        <View style={styles.logback}>
          <TextInput
            style={{ width: 305, marginLeft: 15, marginTop: -20 }}
            label="Email"
            value={email}
            onChangeText={(u) => setEmail(u)}
            autoCapitalize="none"
          />
          <TextInput
            style={{
              width: 305,
              marginLeft: 15,
              marginTop: 10,
              marginBottom: 20,
            }}
            label="Password"
            value={pass}
            onChangeText={(p) => setPass(p)}
            secureTextEntry
            autoCapitalize="none"
          />
          <Button
            style={{
              width: 305,
              height: 50,
              marginLeft: 15,
              marginBottom: -20,
              justifyContent: "center",
            }}
            icon="lock-open-outline"
            mode="contained"
            color="tomato"
            onPress={() => {
              if (email === "abc@xyz.io" && pass === "test123") {
                navigation.navigate("RestaurantScreen");
              }
            }}
          >
            login
          </Button>
        </View>
      </ImageBackground>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  image: {
    flex: 1,
    opacity: 0.7,
  },
  backbutton: {
    position: "absolute",
    //flex: 1,
    width: 20,
    margin: 20,
    justifyContent: "flex-start",
    marginTop: 70,
    width: 100,
  },
  logback: {
    // justifyContent: "center",
    // alignItems: "center",
    // flex: 1,
    //position: "absolute",
    //backgroundColor: "white",
    position: "absolute",
    opacity: 0.9,
    //padding: 110,
    height: 250,
    width: 335,
    backgroundColor: "white",
    marginLeft: 30,
    marginTop: 300,
    justifyContent: "center",
  },
});
