import React from "react";
import { ImageBackground, StyleSheet, View } from "react-native";
import { Button } from "react-native-paper";
import { Navigation } from "../../../infrastructure/navigation";
import LottieView from "lottie-react-native";

export const AccountScreen = ({ navigation }) => {
  return (
    <View style={styles.container}>
      <ImageBackground
        style={styles.image}
        source={require("/Users/developer/Desktop/Vidipta/Projects/MealsToGo/home_bg.jpg")}
      >
        <View
          style={{
            marginTop: -400,
            width: "100%",
            height: "40%",
            opacity: 1,
          }}
        >
          <LottieView
            key="animation"
            autoPlay
            loop
            resizeMode="cover"
            source={require("../../../../assets/watermelon.json")}
          />
        </View>
        <View style={styles.accback}>
          <Button
            style={styles.loginbutton}
            icon="lock-open-outline"
            mode="contained"
            color="tomato"
            onPress={() => {
              navigation.navigate("LoginScreen");
            }}
          >
            Login
          </Button>
          <Button
            style={styles.registerbutton}
            icon="account"
            mode="contained"
            color="tomato"
            onPress={() => {}}
          >
            {" "}
            register
          </Button>
        </View>
      </ImageBackground>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  image: {
    flex: 1,
    justifyContent: "center",
    opacity: 0.7,
  },
  accback: {
    position: "absolute",
    opacity: 0.9,
    padding: 90,
    height: 50,
    width: 250,
    backgroundColor: "white",
    marginLeft: 70,
  },
  loginbutton: {
    position: "absolute",
    flex: 1,
    margin: 20,
    marginTop: 50,
    width: 210,
    opacity: 1,
  },
  registerbutton: {
    position: "absolute",
    flex: 1,
    marginTop: 100,
    width: 210,
    opacity: 1,
    margin: 20,
  },
});
