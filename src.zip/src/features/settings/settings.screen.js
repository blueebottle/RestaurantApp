import React from "react";
import { View, StyleSheet, Text, TouchableOpacity } from "react-native";
import { Button, Avatar } from "react-native-paper";
import { Camera } from "./camera.screen";

export const SettingsScreen = ({ navigation }) => {
  return (
    <View>
      <TouchableOpacity
        onPress={() => {
          null;
        }}
      >
        <Avatar.Icon
          style={{
            backgroundColor: "black",
            margin: 20,
            marginLeft: 130,
          }}
          size={130}
          icon="human"
          color="white"
        ></Avatar.Icon>
      </TouchableOpacity>
      <Text
        style={{
          marginLeft: 155,
          marginTop: -10,
          marginBottom: 20,
        }}
      >
        abc@xyz.io
      </Text>
      <Button
        style={{
          width: 120,
          margin: 20,
        }}
        icon="logout"
        mode="contained"
        color="white"
        onPress={() => {
          navigation.navigate("AccountScreen");
        }}
      >
        logout
      </Button>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
});
