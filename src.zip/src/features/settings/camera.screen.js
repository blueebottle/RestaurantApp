import React from "react";
import { View, Text } from "react-native";

export const Camera = () => {
  return (
    <View style={{ flex: 1 }}>
      <Text> Camera Screen</Text>
    </View>
  );
};
