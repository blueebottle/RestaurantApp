import React from "react";
import { StyleSheet, Text, View } from "react-native";
import { Card } from "react-native-paper";
import OpenNowSvg from "../../../../assets/opennow";
import StarSvg from "../../../../assets/star";
import { colors } from "../../../infrastructure/theme/colors";
import { Favourite } from "../../../components/favourites/favourite.component";

const RestaurantInfo = ({ restaurant = {} }) => {
  const {
    name = "Some Restaurant",
    icon,
    photos = [
      "https://media.istockphoto.com/photos/grilled-chicken-meat-and-fresh-vegetable-salad-of-tomato-avocado-and-picture-id1295633127?s=612x612",
    ],
    address = "11th Random Street",
    isOpenNow = true,
    rating = 4,
    isClosedTemporarily,
  } = restaurant;

  const ratingArray = Array.from(new Array(Math.floor(rating)));
  return (
    <Card style={styles.card}>
      <Favourite restaurant={restaurant} />
      <Card.Cover style={styles.cover} source={{ uri: photos[0] }} />

      <Text style={styles.text}>{name}</Text>
      <View style={{ flexDirection: "row" }}>
        <View style={styles.rating}>
          {ratingArray.map(() => (
            <StarSvg style={styles.starsvg} width={20} height={20} />
          ))}
        </View>
        <View style={styles.opennowsvg}>
          {isOpenNow ? (
            <OpenNowSvg width={20} height={20} />
          ) : (
            <Text style={{ color: "red" }}> CLOSED TEMPORARILY</Text>
          )}
        </View>
      </View>

      <Text style={styles.address}>{address}</Text>
    </Card>
  );
};

const styles = StyleSheet.create({
  cover: {
    backgroundColor: "white",
    padding: 14,
  },
  card: {
    backgroundColor: "white",
    shadowOpacity: 0.2,
    shadowOffset: { width: -2, height: 4 },
    shadowRadius: 5,
    marginBottom: 15,
  },
  text: {
    fontFamily: "cochin",
    fontSize: 20,
    padding: 15,
    paddingBottom: 4,
    color: colors.ui.primary,
  },

  address: {
    fontFamily: "cochin",
    fontSize: 13,
    color: colors.ui.primary,
    padding: 15,
    paddingTop: 3,
  },

  starsvg: {
    marginLeft: 15,
    marginHorizontal: -10,
  },

  rating: {
    flexDirection: "row",
  },

  opennowsvg: {
    flex: 1,
    alignItems: "flex-end",
    marginRight: 15,
  },
});

export default RestaurantInfo;
